SQL> create table vehicle(vehicle_id number(5) primary key, vehicle_name varchar
2(50), purchase_date date, price number(15,2), city varchar2(20));

Table created.

SQL> create sequence vehicle_seq start with 1000;

Sequence created.

SQL> commit;

Commit complete.
