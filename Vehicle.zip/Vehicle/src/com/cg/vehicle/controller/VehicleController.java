package com.cg.vehicle.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.vehicle.dto.Vehicle;
import com.cg.vehicle.exception.VehicleException;
import com.cg.vehicle.service.VehicleService;
import com.cg.vehicle.service.VehicleServiceImpl;

/**
 * Servlet implementation class VehicleController
 */
@WebServlet("/VehicleController")
public class VehicleController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VehicleController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String operation = request.getParameter("action");
		PrintWriter pw = response.getWriter();
		RequestDispatcher view = null;
		VehicleService service = new VehicleServiceImpl();
		if (operation != null && "add".equals(operation)) {
			view = request.getRequestDispatcher("addDetails.html");
			view.forward(request, response);
		}
		if (operation != null && "Append Vehicle".equals(operation)) {
			String vehicleName = request.getParameter("vehicleName");
			LocalDate purchaseDate = LocalDate.parse(request
					.getParameter("purchaseDate"));
			float price = Float.parseFloat(request
					.getParameter("price"));
			String city = request.getParameter("city");
			Vehicle vehicle = new Vehicle();
			vehicle.setVehicleName(vehicleName);
			vehicle.setPurchaseDate(purchaseDate);
			vehicle.setPrice(price);
			vehicle.setCity(city);
			
			try {
				int records = service.addDetails(vehicle);
				if (records != 0) {
					view = request.getRequestDispatcher("success.html");
					view.forward(request, response);
				} else {
					pw.println("Inserting vehicle details failed");
					view = request.getRequestDispatcher("error.html");
					view.include(request, response);
				}
			} catch (VehicleException e) {
				pw.println("Error while inserting vehicle details");
				view = request.getRequestDispatcher("error.html");
				view.include(request, response);
			}
		} if(operation != null && "view".equals(operation)) {
			try {
				ArrayList<Vehicle> vehicleList = service.viewVehicles();
				if (vehicleList != null) {
					Iterator<Vehicle> vehicleIterator = vehicleList.iterator();
					pw.println("<body>");
					pw.println("<table border='1'>");
					pw.println("<tr>");
					pw.println("<th>Vehicle ID</th>");
					pw.println("<th>Vehicle Name</th>");
					pw.println("<th>Vehicle Purchase Date</th>");
					pw.println("<th>Vehicle Price</th>");
					pw.println("<th>City</th>");
					pw.println("</tr>");
					while(vehicleIterator.hasNext()) {
						Vehicle vehicle = vehicleIterator.next();
						pw.println("<tr>");
						pw.println("<td>"+vehicle.getVehicleId()+"</td>");
						pw.println("<td>"+vehicle.getVehicleName()+"</td>");
						pw.println("<td>"+vehicle.getPurchaseDate()+"</td>");
						pw.println("<td>"+vehicle.getPrice()+"</td>");
						pw.println("<td>"+vehicle.getCity()+"</td>");
						pw.println("</tr>");
					}
					pw.println("</table>");
					pw.println("<a href='index.html'>Go Back to Home</a>");
					pw.println("</body>");
				} else {
					pw.println("Fetching vehicle details failed");
					view = request.getRequestDispatcher("error.html");
					view.include(request, response);
				}
			} catch (VehicleException e) {
				pw.println("Error while fetching book details");
				view = request.getRequestDispatcher("error.html");
				view.include(request, response);
			}
		}
	}

	}


