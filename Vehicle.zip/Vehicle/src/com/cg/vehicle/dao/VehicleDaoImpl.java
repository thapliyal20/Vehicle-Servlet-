package com.cg.vehicle.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.vehicle.dto.Vehicle;
import com.cg.vehicle.exception.VehicleException;
import com.cg.vehicle.util.DBUtil;
public class VehicleDaoImpl implements VehicleDao{
	Connection connection = null;
	Statement statement = null;
	ResultSet rsSet = null;
	PreparedStatement preparedStatement = null;

	@Override
	public int addDetails(Vehicle vehicle) throws VehicleException {
		connection = DBUtil.obtainConnection();
		String sql = "INSERT INTO vehicle values(vehicle_seq.nextval,?,?,?,?)";
		int recordInserted = 0;
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, vehicle.getVehicleName());
			preparedStatement.setDate(2, java.sql.Date.valueOf(vehicle.getPurchaseDate()));
			preparedStatement.setFloat(3,vehicle.getPrice());
			preparedStatement.setString(4, vehicle.getCity());
			recordInserted = preparedStatement.executeUpdate();
		} catch (SQLException e) {
			throw new VehicleException("Error while inserting values::"
					+ e.getMessage());
		}
		return recordInserted;
	}

	@Override
	public ArrayList<Vehicle> viewVehicles() throws VehicleException {
		ArrayList<Vehicle> vehicleList = new ArrayList<Vehicle>();
		connection = DBUtil.obtainConnection();
		String sql = "SELECT vehicle_id,vehicle_name,purchase_date,price,city from vehicle";
		try {
			statement = connection.createStatement();
			rsSet = statement.executeQuery(sql);
			while (rsSet.next()) {
				Vehicle vehicle = new Vehicle();
				vehicle.setVehicleId(rsSet.getInt(1));
				vehicle.setVehicleName(rsSet.getString(2));
				vehicle.setPurchaseDate(rsSet.getDate(3).toLocalDate());
				vehicle.setPrice(rsSet.getFloat(4));
				vehicle.setCity(rsSet.getString(5));
				

				vehicleList.add(vehicle);
			}
		} catch (SQLException e) {
			throw new VehicleException("Error while fetching values::"
					+ e.getMessage());
		}
		return vehicleList;
	}

}
