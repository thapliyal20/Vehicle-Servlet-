package com.cg.vehicle.dao;

import java.util.ArrayList;

import com.cg.vehicle.dto.Vehicle;
import com.cg.vehicle.exception.VehicleException;


public interface VehicleDao {
	public int addDetails(Vehicle vehicle) throws VehicleException;
	public ArrayList<Vehicle> viewVehicles() throws VehicleException;

}
