package com.cg.vehicle.service;

import java.util.ArrayList;

import com.cg.vehicle.dto.Vehicle;
import com.cg.vehicle.exception.VehicleException;

public interface VehicleService {
	public int addDetails(Vehicle vehicle) throws VehicleException;
	public ArrayList<Vehicle> viewVehicles() throws VehicleException;

}
