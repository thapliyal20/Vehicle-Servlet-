package com.cg.vehicle.service;

import java.util.ArrayList;

import com.cg.vehicle.dao.VehicleDao;
import com.cg.vehicle.dao.VehicleDaoImpl;
import com.cg.vehicle.dto.Vehicle;
import com.cg.vehicle.exception.VehicleException;

public class VehicleServiceImpl implements VehicleService{
	
	VehicleDao vehicleDao;

	public VehicleServiceImpl() {
		vehicleDao = new VehicleDaoImpl();
	}
	@Override
	public int addDetails(Vehicle vehicle) throws VehicleException {
		return vehicleDao.addDetails(vehicle);
	}

	@Override
	public ArrayList<Vehicle> viewVehicles() throws VehicleException {
		return vehicleDao.viewVehicles();
	}

}
