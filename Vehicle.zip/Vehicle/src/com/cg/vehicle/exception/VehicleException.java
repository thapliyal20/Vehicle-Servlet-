package com.cg.vehicle.exception;

public class VehicleException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public VehicleException(String message) {
		super(message);
	}

}
